version_info = (0, 11, 8)
__version__ = ".".join(map(str, version_info))
